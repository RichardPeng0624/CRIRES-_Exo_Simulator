# setup.py
from setuptools import setup, find_packages

setup(
    name='exocrires',
    version='1.4',
    packages=find_packages(),
    install_requires=[],
)# List your dependencies here
