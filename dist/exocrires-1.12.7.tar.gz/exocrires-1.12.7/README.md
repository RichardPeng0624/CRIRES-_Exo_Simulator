# EXOCRIRES
-- A homemade CRIRES+ observation simulator for exoplanets-- 

Welcome to EXOCRIRES V1.0! This is a 2-D spectra ("raw images") simulator to study and analyze the feasibility of HDS observation for directly imaged planetary systems.


![image](https://github.com/RichardPeng0624/CRIRES_Exo_Simulator/assets/56910910/95d67f7b-8edf-406a-a6c3-b98eb5c91fc6)
