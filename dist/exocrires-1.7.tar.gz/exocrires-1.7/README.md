# EXOCRIRES
-- A homemade CRIRES+ observation simulator for exoplanets-- 

Welcome to EXOCRIRES V1.0! This is a 2-D spectra ("raw images") simulator to study and analyze the feasibility of HDS observation for directly imaged planetary systems.


